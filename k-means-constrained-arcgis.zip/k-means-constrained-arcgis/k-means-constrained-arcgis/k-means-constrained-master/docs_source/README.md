Build docs:
```
make html
mv _build/html ../docs
tocuh ../docs/.nojekyll
``