This repository introduces custom distance metric based on ArcGIS. It is based on [k-means-constrained](https://github.com/joshlk/k-means-constrained.git) Please see the __LICENSE.md__ file for __Licence, Copyright and Citations__ information.


### Create a virtual env
```
python3 -m venv .venv
source .venv/bin/activate
```

### Install dependencies
```
pip3 install -r k-means-constrained-arcgis/k-means-constrained-master/requirements.txt
pip3 install cython functools

__Note__: if functools does not build, skip it for now

cd k-means-constrained-arcgis/k-means-constrained-master/k_means_constrained/sklearn_import/cluster/
cythonize _k_means.pyx
cd ../../../
```

### Build package
 ```
cd k-means-constrained-arcgis/k-means-constrained-master
python3 setup.py build
```

### Run tests
```
python setup.py test
```

### Install the built package (optional)
```
python setup.py install
```

## Citations
If you use this software in your research, please use the following citation:
```
@software{RajeshTewari_k-means-constrained_arcgis_2024,
author = {Rajesh, Tewari},
month = mar,
title = {{k-means-constrained-arcgis}},
url = {https://github.com/joshlk/k-means-constrained-arcgs},
year = {2024}
}
```
